H.51 <- c(1, -1, -1, 0, 0)
H.52 <- c(0, 0, 0, 1, -1)
H51 <- summary(bh5lrtest(z = H1, H = H.51, r = 2))
H52 <- summary(bh5lrtest(z = H1, H = H.52, r = 2))
