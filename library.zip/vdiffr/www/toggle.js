
document.addEventListener('toggled', function(event) {
  var status = document.getElementById('shiny-toggle-status');
  if (event.now_active === 'before') {
    status.innerHTML = 'Before';
  } else {
    status.innerHTML = 'After';
  }
});

// Disable/Enable validate buttons
Shiny.addCustomMessageHandler('toggle-validate-btns-handler', toggleBtns);
function toggleBtns(message) {
  document.getElementById('group_validation_button').disabled = message;
  document.getElementById('case_validation_button').disabled = message;
}